package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.hardware.SensorEvent;
import android.os.Bundle;
import android.widget.TextView;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEventListener;
import android.content.Context;

class MySensorEventListener implements SensorEventListener {
    private Context context;
    private TextView textView;

    public MySensorEventListener(Context context, TextView textView) {
        this.context = context;
        this.textView = textView;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        textView.setText(R.string.changesensor);
        int heart_rate = 0;
        if (event.sensor.getType() == Sensor.TYPE_HEART_RATE) {
            heart_rate = (int)event.values[0];
        }
        String s = "heart rate: "+heart_rate;
        textView.setText(s);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int a) {
    }
}

public class MainActivity extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.myTextView);

        SensorManager mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED) {
            textView.setText(R.string.sensor_permission);
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.BODY_SENSORS}, 1);
        }

        String wait_sensor = "Waiting for data from sensor: " + SensorManager.SENSOR_STATUS_UNRELIABLE;
        textView.setText(wait_sensor);

        SensorEventListener sensorListener = new MySensorEventListener(getBaseContext(), textView);
        Sensor mHeartRateSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);

        mSensorManager.registerListener(sensorListener, mHeartRateSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }
}

/*
public class MainActivity extends AppCompatActivity{
    SensorManager mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

    mSensorManager.getS


}
*/

